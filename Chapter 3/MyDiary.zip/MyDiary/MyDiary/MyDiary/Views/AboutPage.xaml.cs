﻿
using Xamarin.Forms;

namespace MyDiary.Views
{
  public partial class AboutPage : ContentPage
  {
    public AboutPage()
    {
      InitializeComponent();
    }
  }
}

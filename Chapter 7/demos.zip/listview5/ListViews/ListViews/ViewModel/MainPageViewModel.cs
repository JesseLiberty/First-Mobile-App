﻿using ListViews.Model;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using Xamarin.Forms;

namespace ListViews.ViewModel
{
  class MainPageViewModel : INotifyPropertyChanged
  {
    public ObservableCollection<Person> People { get; set; } =
      new ObservableCollection<Person>();
    public ICommand ItemSelectedCommand { get; private set; }

    private string selectedItemText;
    public string SelectedItemText {
      get { return selectedItemText; }
      set
      {
        selectedItemText = value;
        RaisePropertyChanged();
      }
    }

    public MainPageViewModel()
    {
      for(int i = 0; i < 5; i++)
      {
        Person person = new Person();
        person.FirstName = $"Jesse {i.ToString()}";
        person.LastName = $"Liberty {i.ToString()}";
        person.Address = i.ToString() + " Main Street";
        People.Add(person);
      }

      ItemSelectedCommand = new Command<Person>(HandleItemSelected);

    }

    private void HandleItemSelected(Person person)
    {
      SelectedItemText = $"{person.FirstName} {person.LastName}";
    }

    public event PropertyChangedEventHandler PropertyChanged;
    protected void RaisePropertyChanged(
    [CallerMemberName] string caller = "")
    {
      if (PropertyChanged != null)
      {
        PropertyChanged(this, new PropertyChangedEventArgs(caller));
      }
    }

  }
}

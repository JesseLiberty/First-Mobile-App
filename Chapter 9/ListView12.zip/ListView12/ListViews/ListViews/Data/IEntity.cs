﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ListViews.Data
{
  public interface IEntity
  {
    int ID { get; set; }
  }
}

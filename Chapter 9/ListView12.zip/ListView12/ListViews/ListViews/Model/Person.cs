﻿using ListViews.Data;
using SQLite;

namespace ListViews.Model
{
  public class Person : IEntity
  {
    
    public int ID { get; set; }
    public string FirstName { get; set; }
    public string LastName { get; set; }
    public string PhoneNumber { get; set; }


  }
}

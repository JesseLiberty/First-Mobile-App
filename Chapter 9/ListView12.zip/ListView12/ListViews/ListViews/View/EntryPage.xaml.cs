﻿using ListViews.Model;
using ListViews.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;
using Plugin.Connectivity;

namespace ListViews
{
   [XamlCompilation(XamlCompilationOptions.Compile)]
   public partial class EntryPage : ContentPage
   {

      private List<Person> people = new List<Person>();
      private static int ids = 0;

      public EntryPage()
      {
         InitializeComponent();

         CrossConnectivity.Current.ConnectivityChanged += (sender, args) =>
         {
            DisplayAlert("Connectivity Changed",
                        "IsConnected: " + args.IsConnected.ToString(),
                        "OK");
         };

      }

      private void Button_Clicked(object sender, EventArgs e)
      {
         bool IsConnected = CrossConnectivity.Current.IsConnected;
         DisplayAlert("Connected?",
                      $"We are connected to the internet: {IsConnected}",
                     "OK");

         var person = new Person();
         person.ID = ids++;
         person.FirstName = FirstNameEntry.Text;
         person.LastName = LastNameEntry.Text;
         person.PhoneNumber = PhoneNumberEntry.Text;
         FirstNameEntry.Text = "";
         LastNameEntry.Text = "";
         PhoneNumberEntry.Text = "";
         people.Add(person);


      }

      private void GoToList(object sender, EventArgs e)
      {
         Navigation.PushAsync(new MainPage(people), true);
      }
   }
}
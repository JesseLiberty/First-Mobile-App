﻿using ListViews.Data;
using ListViews.Model;
using ListViews.ViewModel;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xamarin.Forms;

namespace ListViews
{
  public partial class MainPage : ContentPage
  {
    public ObservableCollection<Person> People { get; set; } = 
      new ObservableCollection<Person>();
    public MainPage(List<Person> people)
    {
      foreach(Person person in people)
      {
        People.Add(person);
      }
      InitializeComponent();
      BindingContext = this;
    }

    public void OnStore(object o, EventArgs e)
    {
      var repo = new PersonRepository();
      repo.Save(People);
    }

    public void OnRestore(object o, EventArgs e)
    {
      var repo = new PersonRepository();
      var people = repo.GetAll();
      foreach (Person person in people)
      {
        People.Add(person);
      }
    }

      private void BackToEntry(object sender, EventArgs e)
    {
      Navigation.PushAsync(new EntryPage());
    }
  }
}

﻿using System;
using System.Globalization;

namespace Internationalization {
   public interface ILocalize {
      CultureInfo GetCurrentCultureInfo();
      void SetLocale( CultureInfo ci );

   }
}

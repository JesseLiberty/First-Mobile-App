﻿using Xamarin.Forms;

namespace Internationalization {
   public partial class InternationalizationPage : ContentPage {
      public InternationalizationPage() {
         InitializeComponent();
      }

      void Handle_Clicked( object sender,System.EventArgs e ) {
         Navigation.PushAsync( new SelectLanguagePage() );
      }
   }
}

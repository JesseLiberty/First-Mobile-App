﻿using System;
using System.Collections.Generic;
using System.Globalization;
using Xamarin.Forms;

namespace Internationalization {
   public partial class SelectLanguagePage : ContentPage {
      public SelectLanguagePage() {
         InitializeComponent();
      }

      private void OnSpanish( object s,EventArgs e ) {
         SwitchLanguage( "es-MX" );
      }

      private void OnEnglish( object s,EventArgs e ) {
         SwitchLanguage( "en-US" );
      }

      private void SwitchLanguage( string code ) {
         var cultureInfo = new CultureInfo( code );
         ( (App) Application.Current ).Culture = cultureInfo;
         CultureInfo.DefaultThreadCurrentCulture = cultureInfo;
         CultureInfo.DefaultThreadCurrentUICulture = cultureInfo;
         AppResources.Culture = cultureInfo;
         Navigation.PushAsync( new InternationalizationPage() );
      }

   }
}

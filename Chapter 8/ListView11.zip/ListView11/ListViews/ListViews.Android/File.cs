﻿
using ListViews.Droid;
using ListViews.Data;
using Xamarin.Forms;
using System.IO;

[assembly: Dependency(typeof(FileImplementation))]
namespace ListViews.Droid
{
  public class FileImplementation : IFile
  {
    public void SaveText(string filename, string text)
    {
      var documentsPath = System.Environment.GetFolderPath(System.Environment.SpecialFolder.Personal);
   v   var filePath = Path.Combine(documentsPath, filename);
      File.Delete(filePath);
      File.WriteAllText(filePath, text);

    }
    public string LoadText(string filename)
    {
      var documentsPath = System.Environment.
      GetFolderPath(System.Environment.SpecialFolder.Personal);
      var filePath = Path.Combine(documentsPath, filename);
      return System.IO.File.ReadAllText(filePath);
    }

    public void ClearFile(string filename)
    {
      var documentsPath = System.Environment.GetFolderPath(System.Environment.SpecialFolder.Personal);
      var filePath = Path.Combine(documentsPath, filename);
      File.Delete(filePath);

    }

    public bool FileExists(string filename)
    {
      var documentsPath = System.Environment.GetFolderPath(System.Environment.SpecialFolder.Personal);
      var filePath = Path.Combine(documentsPath, filename);

      return File.Exists(filePath);
    }
  }
}
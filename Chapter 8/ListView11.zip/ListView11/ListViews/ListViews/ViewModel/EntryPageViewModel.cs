﻿using ListViews.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ListViews.ViewModel
{


  class EntryPageViewModel
  {

    public string FirstName { get; set; }
    public string LastName { get; set; }
    public string PhoneNumber { get; set; }

    public void AddToPeople()
    {
      Person person = new Person();
      person.FirstName = FirstName;
      person.LastName = LastName;
      person.PhoneNumber = PhoneNumber;
      App.Database.SavePersonAsync(person);
    }
  }
}

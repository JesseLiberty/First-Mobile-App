﻿using ListViews.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace ListViews
{
  [XamlCompilation(XamlCompilationOptions.Compile)]
  public partial class EntryPage : ContentPage
  {
    EntryPageViewModel vm;
    public EntryPage()
    {
      InitializeComponent();
      vm = new EntryPageViewModel();
      BindingContext = vm;
    }

    private void Button_Clicked(object sender, EventArgs e)
    {
      vm.AddToPeople();
      Navigation.PushAsync(new MainPage());
    }
  }
}
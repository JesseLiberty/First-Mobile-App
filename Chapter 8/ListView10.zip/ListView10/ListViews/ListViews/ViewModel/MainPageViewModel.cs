﻿using ListViews.Model;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using Xamarin.Forms;

namespace ListViews.ViewModel
{
  class MainPageViewModel : INotifyPropertyChanged
  {
    public ObservableCollection<Person> People { get; set; } = new ObservableCollection<Person>();
    public ICommand ItemSelectedCommand { get; private set; }

    private string selectedItemText;
    public string SelectedItemText {
      get { return selectedItemText; }
      set
      {
        selectedItemText = value;
        RaisePropertyChanged();
      }
    }

    public MainPageViewModel()
    {

      Person person = new Person();
      person.FirstName = "George";
      person.LastName = "WAshington";
      person.PhoneNumber = "555-1212";
      People.Add(person);


      PopulatePeople();



      ItemSelectedCommand = new Command<Person>(HandleItemSelected);

    }

    private async void PopulatePeople()
    {
      List<Person> people = await App.Database.GetPeopleAsync();
      foreach (Person person in people)
      {
        People.Add(person);
      }
    }

    private void HandleItemSelected(Person person)
    {
      SelectedItemText = $"{person.FirstName} {person.LastName}";
    }

    public event PropertyChangedEventHandler PropertyChanged;
    protected void RaisePropertyChanged(
    [CallerMemberName] string caller = "")
    {
      if (PropertyChanged != null)
      {
        PropertyChanged(this, new PropertyChangedEventArgs(caller));
      }
    }

  }
}

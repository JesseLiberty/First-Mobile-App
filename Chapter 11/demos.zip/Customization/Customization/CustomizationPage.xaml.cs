﻿using System;
using Xamarin.Forms;

namespace Customization {
   public partial class CustomizationPage : ContentPage {
      public CustomizationPage() {
         InitializeComponent();
      }

      protected override void OnAppearing() {
         base.OnAppearing();
         theButton.Effects.Add( new ButtonGradientEffect() );
      }

      private void OnSliderValueChanged( object s,ValueChangedEventArgs e ) {
         Color gradientColor = new Color(
            e.NewValue / 255.0,e.NewValue / 255.0,e.NewValue / 255.0 );
         ButtonGradientEffect.SetGradientColor( theButton,gradientColor );
      }

   }
}

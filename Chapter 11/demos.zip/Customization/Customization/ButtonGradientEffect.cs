﻿using System;
using Xamarin.Forms;

namespace Customization {
   public class ButtonGradientEffect : RoutingEffect {

      public ButtonGradientEffect() : base( "jesseliberty.com.ButtonGradientEffect" ) {
      }

      public static readonly BindableProperty GradientColorProperty =
         BindableProperty.CreateAttached( "GradientColor",
                                         typeof( Color ),
                                         typeof( ButtonGradientEffect ),
                                         Color.Black );

      public static void SetGradientColor( VisualElement visualElement,Color color ) {
         visualElement.SetValue( GradientColorProperty,color );
      }

      public static Color GetGradientColor( VisualElement visualElement ) {
         return (Color) visualElement.GetValue( GradientColorProperty );
      }
   }
}

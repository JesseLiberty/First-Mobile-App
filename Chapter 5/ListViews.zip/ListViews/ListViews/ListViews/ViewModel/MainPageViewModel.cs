﻿using ListViews.Model;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ListViews.ViewModel
{
  class MainPageViewModel
  {
    public ObservableCollection<Person> People { get; set; } =
      new ObservableCollection<Person>();

    public MainPageViewModel()
    {
      for(int i = 1; i<6; i++)
      {
        Person person = new Person();
        person.FirstName = "Jesse ";
        person.LastName = "Liberty" + i.ToString();
        person.Address = i.ToString() + " Main Street";
        person.ImageSource = "man" + i.ToString() + ".jpeg";
        People.Add(person);
      }
    }

  }
}
